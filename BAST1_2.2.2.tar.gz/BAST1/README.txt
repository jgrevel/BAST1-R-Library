The line:
#' @importFrom Rcpp evalCpp

has been added to the BAST1-package.R file
This has solved the issue described below, and renders its fix as unnecessary. roxygen2 now builds the NAMESPACE correctly.




~ Re: Aaron's email dated 04/04/2016

When using devtools::document() to rebuild the documentation for each function, roxygen2 rebuilds the NAMESPACE file. This is regardless of whether
	Configure Build Tools... >  Generate documentation with Roxygen > Configure...
has "NAMESPACE file" selected or not.

For this reason, before each time a new source package is built, I should re-add the line:
	importFrom(Rcpp,evalCpp)
to the NAMESPACE file, to ensure compatability with everyone's computers.
