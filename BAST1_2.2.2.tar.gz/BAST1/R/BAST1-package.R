#' BAST1: A package containing BAST R functions.
#'
#' The BAST1 package provides four categories of important functions:
#' Data building, ....
#'
#' @section Data building functions:
#' The Data building functions ...
#'
#' @docType package
#' @name BAST1
#' @importFrom Rcpp evalCpp
#' @useDynLib BAST1
NULL
#> NULL
